// array of employes data

var employee_data = [
  {
    name: "John",
    position: "Engineer",
    office: "Megha",
    extn: "5764",
    startdate: "2023-10-12",
    salary: "100000",
    id: "1",
  },
  {
    name: "Jason",
    position: "Software",
    office: "Westgate",
    extn: "1982",
    startdate: "2023-10-12",
    salary: "50000",
    id: "2",
  },
  {
    name: "Raj",
    position: "Engineer",
    office: "Megha",
    extn: "2344",
    startdate: "2022-10-12",
    salary: "10000",
    id: "3",
  },
  {
    name: "Jay",
    position: "Admin",
    office: "Westgate",
    extn: "1982",
    startdate: "2023-10-12",
    salary: "50000",
    id: "4",
  },
  {
    name: "Parth",
    position: "Engineer",
    office: "Megha",
    extn: "2344",
    startdate: "2022-10-12",
    salary: "10000",
    id: "5",
  },
  {
    name: "Rushabh",
    position: "Software",
    office: "Westgate",
    extn: "1982",
    startdate: "2023-10-12",
    salary: "50000",
    id: "6",
  },
  {
    name: "Taksh",
    position: "Engineer",
    office: "Megha",
    extn: "2344",
    startdate: "2022-10-12",
    salary: "10000",
    id: "7",
  },
  {
    name: "Meet",
    position: "Software",
    office: "Westgate",
    extn: "1982",
    startdate: "2023-10-12",
    salary: "50000",
    id: "8",
  },
  {
    name: "varun",
    position: "QA",
    office: "Megha",
    extn: "2344",
    startdate: "2022-10-12",
    salary: "50000",
    id: "9",
  },
  {
    name: "Pratik",
    position: "Frontend",
    office: "Westgate",
    extn: "1982",
    startdate: "2023-10-12",
    salary: "75000",
    id: "10",
  },
  {
    name: "vivek",
    position: "Backend",
    office: "Westgate",
    extn: "1344",
    startdate: "2021-10-12",
    salary: "80000",
    id: "11",
  },
];

// display data on webpage

window.onload = function () {
  showTable();
};
function showTable() {
  var new_row_data = "<table border='1|1'>";
  for (var i = 0; i < employee_data.length; i++) {
    new_row_data += "<tr>";
    new_row_data += "<td>" + employee_data[i].name + "</td>";
    new_row_data += "<td>" + employee_data[i].position + "</td>";
    new_row_data += "<td>" + employee_data[i].office + "</td>";
    new_row_data += "<td>" + employee_data[i].extn + "</td>";
    new_row_data += "<td>" + employee_data[i].startdate + "</td>";
    new_row_data += "<td>" + employee_data[i].salary + "</td>";
    new_row_data +=
      "<td>" +
      `<button type="button" class='btn edit-btn' data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="editdatas(${employee_data[i].id})">Edit</button>` +
      "</td>";
    new_row_data +=
      "<td>" +
      `<button class='btn delete-btn' onclick="deletedata(${employee_data[i].id})">Delete</button>` +
      "</td>";
  }
  new_row_data += "</table>";
  $(".show-data").html(new_row_data);
  $("#employee_table").DataTable();
}

// add data functionality

function adddata() {
  var ids = employee_data.length + 1;
  var fnamenew = document.getElementById("name").value;
  var positionnew = document.getElementById("position").value;
  var officenamenew = document.getElementById("officename").value;
  var extnnew = document.getElementById("extn").value;
  var startdatenew = document.getElementById("startdate").value;
  var salarynew = document.getElementById("salary").value;






if(fnamenew == "" || positionnew == "" || officenamenew == "" || extnnew == "" || startdatenew == "" || salarynew == ""){
  Swal.fire("Please enter all the details Properly");
}




  var employee = {
    name: fnamenew,
    position: positionnew,
    office: officenamenew,
    extn: extnnew,
    startdate: startdatenew,
    salary: salarynew,
    id: ids,
  };
  employee_data.push(employee);
  document.getElementById("name").value = "";
  document.getElementById("position").value = "";
  document.getElementById("officename").value = "";
  document.getElementById("extn").value = "";
  document.getElementById("startdate").value = "";
  document.getElementById("salary").value = "";
  showTable();
}

// delete data functionality

function deletedata(e) {
  var deletefilter = employee_data.filter((a, i) => {
    if (e == a.id) {
      employee_data.splice(i, 1);
      showTable();
    }
  });
}

function editdatas(ee) {
  console.log(ee);
  ee = ee - 1;

  abc(ee);

  // var ids = employee_data.length + 1;
  // var fnamenew = document.getElementById("name").value;
  // var positionnew = document.getElementById("position").value;
  // var officenamenew = document.getElementById("officename").value;
  // var extnnew = document.getElementById("extn").value;
  // var startdatenew = document.getElementById("startdate").value;
  // var salarynew = document.getElementById("salary").value;

  // var employee = {
  //   name: fnamenew,
  //   position: positionnew,
  //   office: officenamenew,
  //   extn: extnnew,
  //   startdate: startdatenew,
  //   salary: salarynew,
  //   id: ids,
  // };
  // employee_data.push(employee);

  // showTable();
}

function abc(a) {
  var editname = employee_data[a].name;
  // var editposition = employee_data[ee].position;
  // var editofficename = employee_data[ee].office;
  // var editextn = employee_data[ee].extn;
  // var editstartdate = employee_data[ee].startdate;
  // var editsalary = employee_data[ee].salary;
  console.log(editname);
  document.getElementById("nameone").innerHTML = `${editname}`;
  document.getElementById("position").value = "";
  document.getElementById("officename").value = "";
  document.getElementById("extn").value = "";
  document.getElementById("startdate").value = "";
  document.getElementById("salary").value = "";
}

// var row = btn.parentNode.parentNode;
// row.parentNode.removeChild(row);

// function addrow() {
//     var fnamenew = document.getElementById("name").value;
//     var positionnew = document.getElementById("position").value;
//     var officenamenew = document.getElementById("officename").value;
//     var extnnew = document.getElementById("extn").value;
//     var startdatenew = document.getElementById("startdate").value;
//     var salarynew = document.getElementById("salary").value;

//     tbodyEl.innerHTML += `
//     <tr>
//         <td>${fnamenew}</td>
//         <td>${positionnew}</td>
//         <td>${officenamenew}</td>
//         <td>${extnnew}</td>
//         <td>${startdatenew}</td>
//         <td>${salarynew}</td>
//     </tr>
//     `;
// }

// search functionality

function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("employee_table");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    td1 = tr[i].getElementsByTagName("td")[1];
    td2 = tr[i].getElementsByTagName("td")[2];
    td3 = tr[i].getElementsByTagName("td")[3];
    td4 = tr[i].getElementsByTagName("td")[4];
    td5 = tr[i].getElementsByTagName("td")[5];

    if (td1) {
      console.log("into1");
      let txtValue = td1.textContent || td1.innerText;
      let text2 = td.textContent || td.innerText;
      let text3 = td2.textContent || td2.innerText;

      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else if (text2.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}

//  $(document).ready(function () {
//    $("#employee_table").DataTable();
//  });
