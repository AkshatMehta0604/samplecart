// array of employes data

var employee_data = [
  {
    name: "John",
    position: "Engineer",
    office: "Megha",
    extn: "5764",
    startdate: "2023-10-12",
    salary: "100000",
    id: "1",
  },
  {
    name: "Jason",
    position: "Software",
    office: "Westgate",
    extn: "1982",
    startdate: "2023-10-12",
    salary: "50000",
    id: "2",
  },
];

// display data on webpage

window.onload = function () {
  showTable();
};
function showTable() {
  var new_row_data = "<table border='1|1'>";
  for (var i = 0; i < employee_data.length; i++) {
    new_row_data += "<tr>";
    new_row_data += "<td>" + employee_data[i].name + "</td>";
    new_row_data += "<td>" + employee_data[i].position + "</td>";
    new_row_data += "<td>" + employee_data[i].office + "</td>";
    new_row_data += "<td>" + employee_data[i].extn + "</td>";
    new_row_data += "<td>" + employee_data[i].startdate + "</td>";
    new_row_data += "<td>" + employee_data[i].salary + "</td>";
    new_row_data += "<td>" + `<button type="button" class="" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="editdatas(${employee_data[i].id})">Edit</button>` + "</td>";
    new_row_data += "<td>" +
      `<button class='btn delete-btn' onclick="deletedata(${employee_data[i].id})">Delete</button>` +
      "</td>";
  }
  new_row_data += "</table>";
  $(".show-data").html(new_row_data);
}

// add data functionality

function adddata() {

  var ids = employee_data.length + 1;
  var fnamenew = document.getElementById("name").value;
  var positionnew = document.getElementById("position").value;
  var officenamenew = document.getElementById("officename").value;
  var extnnew = document.getElementById("extn").value;
  var startdatenew = document.getElementById("startdate").value;
  var salarynew = document.getElementById("salary").value;

  var employee = {
    name: fnamenew,
    position: positionnew,
    office: officenamenew,
    extn: extnnew,
    startdate: startdatenew,
    salary: salarynew,
    id: ids,
  };
  employee_data.push(employee);
  document.getElementById("name").value = "";
  document.getElementById("position").value = "";
  document.getElementById("officename").value = "";
  document.getElementById("extn").value = "";
  document.getElementById("startdate").value = "";
  document.getElementById("salary").value = "";
  showTable();
}

// delete data functionality

function deletedata(e) {
  var deletefilter = employee_data.filter((a, i) => {
    if (e == a.id) {
      employee_data.splice(i, 1);
      showTable();
    }
  });
}



function editdatas(ee){
  console.log(ee);
  ee = ee - 1;

  abc(ee);

  


  // var ids = employee_data.length + 1;
  // var fnamenew = document.getElementById("name").value;
  // var positionnew = document.getElementById("position").value;
  // var officenamenew = document.getElementById("officename").value;
  // var extnnew = document.getElementById("extn").value;
  // var startdatenew = document.getElementById("startdate").value;
  // var salarynew = document.getElementById("salary").value;

  // var employee = {
  //   name: fnamenew,
  //   position: positionnew,
  //   office: officenamenew,
  //   extn: extnnew,
  //   startdate: startdatenew,
  //   salary: salarynew,
  //   id: ids,
  // };
  // employee_data.push(employee);
  
  // showTable();
}

function abc(a){
  var editname = employee_data[a].name;
  // var editposition = employee_data[ee].position;
  // var editofficename = employee_data[ee].office;
  // var editextn = employee_data[ee].extn;
  // var editstartdate = employee_data[ee].startdate;
  // var editsalary = employee_data[ee].salary;
  console.log(editname);
  document.getElementById("nameone").innerHTML = `${editname}`;
  document.getElementById("position").value = "";
  document.getElementById("officename").value = "";
  document.getElementById("extn").value = "";
  document.getElementById("startdate").value = "";
  document.getElementById("salary").value = "";
}


// var row = btn.parentNode.parentNode;
// row.parentNode.removeChild(row);

// function addrow() {
//     var fnamenew = document.getElementById("name").value;
//     var positionnew = document.getElementById("position").value;
//     var officenamenew = document.getElementById("officename").value;
//     var extnnew = document.getElementById("extn").value;
//     var startdatenew = document.getElementById("startdate").value;
//     var salarynew = document.getElementById("salary").value;

//     tbodyEl.innerHTML += `
//     <tr>
//         <td>${fnamenew}</td>
//         <td>${positionnew}</td>
//         <td>${officenamenew}</td>
//         <td>${extnnew}</td>
//         <td>${startdatenew}</td>
//         <td>${salarynew}</td>
//     </tr>
//     `;
// }
